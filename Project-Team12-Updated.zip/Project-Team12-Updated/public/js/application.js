let currentFilter = "all"
function getcharacterList(){
    let xhttp = new XMLHttpRequest();
    let url = "http://localhost:3050/application/character" + (currentFilter == "all" ? "" : "?filter=" + currentFilter);
    xhttp.open("GET", url, false);
    xhttp.setRequestHeader("Accept", "application/json");
    xhttp.send();
    if (xhttp.status == 200) {
        data = JSON.parse(xhttp.responseText);
    } else {
        console.error("Request Failed")
    }
    header = document.getElementById("content")
    template = renderListPage(data) 
    header.innerHTML = template
}

function getcharacterDetail(character){
    let xhttp = new XMLHttpRequest();
    let url = "http://localhost:3050/application/character/" + character;
    xhttp.open("GET", url, false);
    xhttp.setRequestHeader("Accept", "application/json");
    xhttp.send();
    if (xhttp.status == 200) {
        data = JSON.parse(xhttp.responseText);
    } else {
        console.error("Request Failed")
    }
   // content = document.getElementById("content")
   // template = renderDetailPage(data) 
   // content.innerHTML = template
}
function toggleFavorite(name){
    
    let xhttp = new XMLHttpRequest();
    let url = "http://localhost:3050/application/favorite/" + name +( currentFilter == "all" ? "" : "?filter=" + currentFilter);
    xhttp.open("POST", url, false);
    xhttp.setRequestHeader("Accept", "application/json");
    xhttp.send();
    if (xhttp.status == 200) {
        data = JSON.parse(xhttp.responseText);
    } else {
        console.error("Request Failed")
    }
    content = document.getElementById("content")
    template = renderListPage(data) 
    content.innerHTML = template
}
function renderListPage(characterList){
    let content = ""
    for (let character of characterList){
    //  let button = `<button onclick="getcharacterDetail(${character.id})">${character.name}</button>`
    // content += button
        let card = `
            <div class="card" style="width: 18rem;" data-bs-toggle="modal" data-bs-target="#${character.name}-modal">
                <img src="${character.image}" class="card-img-top">
                <div class="card-body">
                    <h5 class="card-title">${character.name}</h5>
                    <p class="card-text">${character.shortdescription}</p>
                    <i onclick="toggleFavorite('${character.name}')" class="bi-${!character.favorite ? "heart" : "heart-fill icon-red"}"></i>
                </div>
            </div>



            <!-- Modal -->
            <div class="modal fade" id="${character.name}-modal" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
            <div class="modal-dialog modal-dialog-centered">
                <div class="modal-content">
                <div class="modal-header">
                    <h1 class="modal-title fs-5" id="exampleModalLabel">${character.name}</h1>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <div class="modal-body">
                    <div data-bs-toggle="modal" data-bs-target="#exampleModal">
                        <img src="${character.bigimage}" class="card-img-top">
                        <div class="card-body">
                            <p class="card-text">${character.desc}</p>
                        </div>
                    </div>
                

                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
                </div>
                </div>
            </div>
            </div>
        `
        content += card

    }
    return content;
    //let template = `<div>${content}</div>`
    //return template
}
function renderDetailPage(characterDetail){
    let template = `<h1>${characterDetail.name}</h1>
                    <p>${characterDetail.desc}</p>
                    <img src="${characterDetail.image}">`
    return template
}
function setFilter(filter, displayName){
    if (currentFilter != filter){
        currentFilter = filter
        if (filter == "search"){
            let search = document.getElementById("search")
            document.getElementById("filterDropdown").innerHTML ="Current Filter: Searching for " + search.value
            currentFilter = currentFilter + "-" + encodeURIComponent(search.value)
        } else {
            document.getElementById("filterDropdown").innerHTML ="Current Filter: " + displayName
        }
        getcharacterList()
    }
    
}
getcharacterList()