var path = require('path');
var express = require('express');
var router = express.Router();

var applicationController = require('../application/applicationController');


router.get('/character', function(req, res, next) {

    appController = new applicationController();
    let data = appController.getAllCharacters();
    data = filterResults(req.query.filter, data)
    res.send(data);
});

router.get('/character/:id', function(req, res, next) {

    appController = new applicationController();
    let data = appController.getCharacterById(req.params.id);
    data = filterResults(req.query.filter, data)
    res.send(data);
});

router.post('/favorite/:id', function(req, res, next) {

    appController = new applicationController();
    let data = appController.toggleFavorite(req.params.id);
    data = filterResults(req.query.filter, data)
    res.send(data);
});

function filterResults(filter, data){
    if (filter == "all" || !filter)
    return data
    let filterValues = filter.split("-")
    if (filterValues[0] == "search") {
        let search = decodeURIComponent(filterValues[1])
        return data.filter((item)=> {
            return item.name.includes(search) || item.alias.includes(search)
        })
    } else {
        return data.filter((item)=> item[filterValues[0]].replace(" ", "") == filterValues[1])
    }
}













module.exports = router;