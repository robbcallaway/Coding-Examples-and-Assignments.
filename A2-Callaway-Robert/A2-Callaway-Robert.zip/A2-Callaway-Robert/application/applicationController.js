const fs = require('fs');
const path = require("path");

class application {

    constructor(req) {
        this.appData = JSON.parse(fs.readFileSync('./application/data/applicationData.json'));  //read in the /data/applicationData.json file.
        this.req = req;
    }



    renderApplicationPage() {
        this.template = fs.readFileSync('./application/template/applicationTemplate.html').toString();  // read in the /template/applicationTemplate.html file.
        //Render Application Page Here
        let itemList = ""
        for (let i = 0; i < this.appData.length; i++) {
            itemList += `<div><a href=${"."+this.appData[i].url}>${this.appData[i].name}</a></div>`;
        }
        this.template=this.template.replace("{items}", itemList);

    }
    renderContentPage() {
        this.template = fs.readFileSync('./application/template/contentTemplate.html').toString();; // read in the /template/contentTemplate.html file.
        let currentpath=this.req.path
        console.log(currentpath)
        let currentitem=this.appData.find((item) => {
            return item.url==currentpath;
        })
        this.template=this.template.replaceAll("{name}", currentitem.name);
        this.template=this.template.replace("{desc}", currentitem.desc);
        this.template=this.template.replace("{image}",currentitem.image);
        let nextitem = undefined;
        if (currentitem.index >= this.appData.length-1){
            nextitem=this.appData[0]
        } else {
            nextitem=this.appData[currentitem.index+1]
        }
        console.log(nextitem)
        this.template=this.template.replace("{nextPageURL}","."+nextitem.url);
        this.template=this.template.replace("{nextPage}", nextitem.name);

        //Render Content Page Here
    }


    getApplicationPage() {
        this.renderApplicationPage();
        return this.template;
    }

    getContentPage() {
        this.renderContentPage();
        return this.template;
    }


}


module.exports = application;


