var path = require('path');
var express = require('express');
var router = express.Router();

var applicationController = require('../application/applicationController');

router.get('/', function(req, res, next) {
    appController = new applicationController(req);
    html = appController.getApplicationPage();
    res.send(html);
});

router.get('/*', function(req, res, next) {
    appController = new applicationController(req);
    html = appController.getContentPage();
    res.send(html);
});



module.exports = router;