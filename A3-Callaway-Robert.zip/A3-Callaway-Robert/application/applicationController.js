const fs = require("fs")
class application {

    getAllCharacters() {
        let data = JSON.parse(fs.readFileSync("./application/data/applicationData.json"))
        console.log(data)
        return data
    }

    getCharacterById(id) {
        let data = JSON.parse(fs.readFileSync("./application/data/applicationData.json"))
        let character = data.find((item) => {
            return item.id == id
        })
        return character
    }

}


module.exports = application;