function getcharacterList(){
    let xhttp = new XMLHttpRequest();
    let url = "http://localhost:3050/application/character";
    xhttp.open("GET", url, false);
    xhttp.setRequestHeader("Accept", "application/json");
    xhttp.send();
    if (xhttp.status == 200) {
        data = JSON.parse(xhttp.responseText);
    } else {
        console.error("Request Failed")
    }
    header = document.getElementById("header")
    template = renderListPage(data) 
    header.innerHTML = template
}

function getcharacterDetail(character){
    let xhttp = new XMLHttpRequest();
    let url = "http://localhost:3050/application/character/" + character;
    xhttp.open("GET", url, false);
    xhttp.setRequestHeader("Accept", "application/json");
    xhttp.send();
    if (xhttp.status == 200) {
        data = JSON.parse(xhttp.responseText);
    } else {
        console.error("Request Failed")
    }
    content = document.getElementById("content")
    template = renderDetailPage(data) 
    content.innerHTML = template
}
function renderListPage(characterList){
    let content = ""
    for (let character of characterList){
        let button = `<button onclick="getcharacterDetail(${character.id})">${character.name}</button>`
        content += button
    }
    let template = `<div>${content}</div>`
    return template
}
function renderDetailPage(characterDetail){
    let template = `<h1>${characterDetail.name}</h1>
                    <p>${characterDetail.desc}</p>
                    <img src="${characterDetail.image}">`
    return template
}
getcharacterList()